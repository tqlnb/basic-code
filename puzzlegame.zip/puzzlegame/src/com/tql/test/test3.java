package com.tql.test;

public class test3{
    public static void main(String[] args) {
        //new MyJFrame();
        //new MyJFrame2();
        new MyJFrame3();
    }

}
